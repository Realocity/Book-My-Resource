# Book-My-Resource
SEMESTER 6 PROJECT VENUE, RESOURCE AND SERVICE BOOKING MANAGEMENT SYSTEM.

'''
This project is an initiative to create a software system for viewing, marketing, booking and
managing the various venues and services provided by BMCC. This project is divided into two
parts: the user website and the admin android application.

The user website is used for marketing purposes and for sending booking requests by the user.
It will be the consumer end of the software. The admin application is an android based app
that will allow the admin to view, accept and reject the user request. This software is made
with the perspective of solving the problem of extra paperwork and lack of effective and 
efficient communication and transactions between the consumer and BMCC admin.
'''
## Credit :
THE TEAM: SHUBHAM SAPKAL, ANUBHAV ARORA, YUVRAJ GAVHANE.
